﻿using System.Net;

namespace DemoApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            string directoryFolder = "C:\\Users\\YB826BP\\OneDrive - EY\\Desktop\\imp queries\\grepTest";

            string[] allfilesEntries = Directory.GetFiles(directoryFolder);

            var wc = new WebClient();
            var webData = wc.DownloadString("https://www.lipsum.com/");

            Console.WriteLine("Provide content");
            string content = Console.ReadLine();

            Console.WriteLine("Provide Source : file, folder, url");
            string identifySearchSource = Console.ReadLine();

            Console.WriteLine("Provide CaseInsensitiveness : i/c");
            char caseInsensitive = Console.ReadLine()[0];

            Console.WriteLine("Provide Reverse or not : v/n");
            char reverse = Console.ReadLine()[0];

            //Sending files one by one - Folder Case
            if (identifySearchSource == "folder")
            {
                for (int i = 0; i < allfilesEntries.Length; i++)
                {
                    ContentRead.ReadFrom(allfilesEntries[i], content, caseInsensitive, reverse);
                }
            }

            //Sending particular File Case
            if (identifySearchSource == "file")
            {
                Console.WriteLine("Provide File Name :  File1, File2, File3");
                string destfile = Console.ReadLine();

                switch (destfile)
                {
                    case "File1":
                        ContentRead.ReadFrom(allfilesEntries[0], content, caseInsensitive, reverse);
                        break;
                    case "File2":
                        ContentRead.ReadFrom(allfilesEntries[1], content, caseInsensitive, reverse);
                        break;
                    case "File3":
                        ContentRead.ReadFrom(allfilesEntries[2], content, caseInsensitive, reverse);
                        break;
                }
            }

            //Url Case
            if (identifySearchSource == "url")
            {
                if (webData.ToLower().Contains(content.ToLower()))
                {
                    Console.WriteLine("URL " + "---" + content);
                }
            }
        }
    }
}