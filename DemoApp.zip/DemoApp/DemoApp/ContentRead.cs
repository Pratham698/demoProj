﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoApp
{
    public class ContentRead
    {
        public static void ReadFrom(string file, string content, char caseInsensitive = 'c', char reverse = 'n')
        {
            string line;
            using (var reador = File.OpenText(file))
            {
                while ((line = reador.ReadLine()) != null)
                {
                    //Insensitive and no reverse
                    if (caseInsensitive == 'i' && reverse == 'n')
                    {
                        if (line.ToLower().Contains(content.ToLower()))
                        {
                            Console.WriteLine(file + " --- " + line);
                        }
                    }

                    //Insensitive and reverse
                    else if(caseInsensitive == 'i' && reverse == 'v')
                    {
                        if (!line.ToLower().Contains(content.ToLower()))
                        {
                            Console.WriteLine(file + " --- " + line);
                        }
                    }

                    //Rest Cases
                    else
                    {
                        if (line.Contains(content))
                        {
                            Console.WriteLine(file + " --- " + line);
                        }
                    }
                }
            }
        }
    }
}
